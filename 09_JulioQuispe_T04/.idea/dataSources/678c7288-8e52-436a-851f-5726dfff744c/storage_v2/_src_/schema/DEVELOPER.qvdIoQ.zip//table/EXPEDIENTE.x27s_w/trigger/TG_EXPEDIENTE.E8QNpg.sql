create trigger TG_EXPEDIENTE
    before insert
    on EXPEDIENTE
    for each row
BEGIN
SELECT sq_idexp.NEXTVAL INTO :NEW.IDEXP FROM DUAL;
END;
/

