create trigger TG_FUNCIONARIO
    before insert
    on FUNCIONARIO
    for each row
BEGIN
SELECT sq_idfun.NEXTVAL INTO :NEW.IDFUN FROM DUAL;
END;
/

