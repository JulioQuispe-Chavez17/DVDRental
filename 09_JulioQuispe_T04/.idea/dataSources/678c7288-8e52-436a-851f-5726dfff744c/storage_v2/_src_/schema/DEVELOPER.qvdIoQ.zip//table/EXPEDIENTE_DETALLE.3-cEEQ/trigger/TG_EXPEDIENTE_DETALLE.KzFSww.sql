create trigger TG_EXPEDIENTE_DETALLE
    before insert
    on EXPEDIENTE_DETALLE
    for each row
BEGIN
SELECT sq_idexpdet.NEXTVAL INTO :NEW.IDEXPDET FROM DUAL;
END;
/

