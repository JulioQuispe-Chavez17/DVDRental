create trigger TG_AREA
    before insert
    on AREA
    for each row
BEGIN
SELECT sq_idare.NEXTVAL INTO :NEW.IDARE FROM DUAL;
END;
/

