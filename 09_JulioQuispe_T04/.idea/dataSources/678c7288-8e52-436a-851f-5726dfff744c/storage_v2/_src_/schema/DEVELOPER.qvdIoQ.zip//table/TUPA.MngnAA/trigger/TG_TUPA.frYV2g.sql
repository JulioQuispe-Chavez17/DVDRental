create trigger TG_TUPA
    before insert
    on TUPA
    for each row
BEGIN
SELECT sq_idtup.NEXTVAL INTO :NEW.IDTUP FROM DUAL;
END;
/

